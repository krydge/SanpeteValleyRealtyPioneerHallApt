import './ApplyStyle.css'

function ApplyNow() {
    return (
        <div >
            <a className="ApplyNow" target="_blank" href="https://www.hemlane.com/listings/owners/d220038c-85fc-4cb1-8e46-07011cedd72a/">Apply Now</a>
        </div>
    )
}

export default ApplyNow;